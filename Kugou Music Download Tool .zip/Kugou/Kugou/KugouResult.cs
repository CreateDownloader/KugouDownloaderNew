﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kugou
{
    class KugouResult
    {
        public string filename { get; set; }
        public string sqhash { get; set; }
        public string key { get; set; }
    }
}
