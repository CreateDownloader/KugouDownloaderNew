﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Security.Cryptography;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using CCWin;
using CCWin.SkinControl;
using Desharp;
using IrisSkin2;
using MetroSet_UI;
using NServiceBus;
using MaterialSkin;
using KafkaNET;
using KafkaNET.Library;
using Fozzy.Skin;
using Fozzy.Form;
using Fozzy.System;
using Fozzy.Object;

namespace Kugou
{
    public partial class Form1 : CCSkinMain
    {
        public Form1()
        {
            InitializeComponent(); 
        }
        string target = Environment.CurrentDirectory + "\\Download\\";
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
